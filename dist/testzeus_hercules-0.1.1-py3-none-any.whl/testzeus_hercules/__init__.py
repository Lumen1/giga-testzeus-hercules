from testzeus_hercules import core  # type: ignore # noqa: F401
